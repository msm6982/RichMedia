

// Default data for local storage
const defaultData = {
    "haikus": [],
    // Saved search terms from app page
    "savedSearch" : " ",
    "numeralInput" : "1",
    "uiState" : "Type a phrase and click the <b>Search</b> button to view Haikus",
    "recentlySearchedHaikus" : []
  },
  storeName = "msm6982-p1-settings"; 
  
  // Parse and return local storage
  const readLocalStorage = () => {
    let allValues = null;
  
    try{
      allValues = JSON.parse(localStorage.getItem(storeName)) || defaultData;
    }catch(err){
      console.log(`Problem with JSON.parse() and ${storeName} !`);
      throw err;
    }
  
    return allValues;
  };
  
  // Write all passed data to the local 
  const writeLocalStorage = (allValues) => {
    localStorage.setItem(storeName, JSON.stringify(allValues));
  };
  



  // Save the current state of the app page, only overriden when the user searches correctly 
  export const saveAppState = (savedSearch, numeralInput, uiState, recentlySearchedHaikus) => 
  {
    let allValues = readLocalStorage();

    allValues.savedSearch = savedSearch;
    allValues.numeralInput = numeralInput;
    allValues.recentlySearchedHaikus = recentlySearchedHaikus;
    allValues.uiState = uiState;

    writeLocalStorage(allValues);
  }
  
  // Remove a unfavored array, bit bugged in current itteration
  export const removeFavorite = (str) => {
    const allValues = readLocalStorage();
    (findHaikuInFav(str)) ? allValues.haikus.splice(allValues.haikus.indexOf(str),1) : this.return;
    
    writeLocalStorage(allValues);
  }

  // Check if a haikus is in the favorites
  export const findHaikuInFav = (haiku) =>
  {
    if (readLocalStorage().haikus.find(h => `${h.line1}` == `${haiku.line1}`)) {
      return true;
    }

    return false;
  }

  // Add a favored Array
  export const addFavorite = (str) => {
    const allValues = readLocalStorage();
    const haikuObj = {
      "line1" : str.line1,
      "line2" : str.line2,
      "line3" : str.line3,
      };
  
    allValues.haikus.push(haikuObj);
    writeLocalStorage(allValues);
  };

  export const getSavedSearch = () => readLocalStorage().savedSearch;

  export const getSavedNumeralInput = () => readLocalStorage.numeralInput;

  export const getSavedUI = () => readLocalStorage().uiState;

  export const getRecentlySearchedHaikus = () => readLocalStorage().recentlySearchedHaikus;

  export const clearLocalStorage = () => writeLocalStorage(defaultData);

  
  export const getFavorites = () => readLocalStorage().haikus;
  
  export const clearFavorites = () => {
    const allValues = readLocalStorage();
  
    allValues.haikus = [];
    writeLocalStorage(allValues);
  };
  
  // Just clear the local changes made to the app page
  export const clearAppChanges = () => {
    const allValues = readLocalStorage();
    
    allValues.savedSearch = defaultData.savedSearch;
    allValues.numeralInput = defaultData.numeralInput;
    allValues.recentlySearchedHaikus = defaultData.recentlySearchedHaikus;
    allValues.uiState = defaultData.uiState;

    writeLocalStorage(allValues);

  }